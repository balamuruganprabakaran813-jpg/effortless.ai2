self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/0w7o4d6g9pb_e.js"
  ],
  "/404": [
    "static/chunks/404_b_vujg1z4.js"
  ],
  "/[...services]": [
    "static/chunks/1zuhlj6naijve.js"
  ],
  "/_error": [
    "static/chunks/0md3d3rllie7z.js"
  ],
  "/blogs": [
    "static/chunks/0ywi1zont_l0_.js"
  ],
  "/blogs/[id]": [
    "static/chunks/0j64edbi_acpw.js"
  ],
  "/demo": [
    "static/chunks/0botmodsp570p.js"
  ],
  "/privacy-policy": [
    "static/chunks/0io48firek6ed.js"
  ],
  "/security-practices": [
    "static/chunks/0v7jp5wppbf4n.js"
  ],
  "/terms-of-service": [
    "static/chunks/334ypoj5ciloq.js"
  ],
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/sitemap.xml",
        "destination": "/api/sitemap.xml"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/api/hello",
    "/api/processlead",
    "/api/sitemap.xml",
    "/blogs",
    "/blogs/[id]",
    "/demo",
    "/privacy-policy",
    "/security-practices",
    "/terms-of-service",
    "/[...services]"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()