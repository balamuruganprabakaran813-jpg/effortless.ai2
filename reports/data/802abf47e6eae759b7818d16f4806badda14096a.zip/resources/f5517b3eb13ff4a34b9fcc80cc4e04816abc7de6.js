__turbopack_load_page_chunks__("/", [
  "static/chunks/0g7itv9kac3o0.js",
  "static/chunks/20vmwsdm9vs44.js",
  "static/chunks/33x-gmmbn8f_p.js",
  "static/chunks/26pmww7z768fq.js",
  "static/chunks/1zhe0cil0hd6h.js",
  "static/chunks/2isxrfz19d6im.js",
  "static/chunks/2yq1jcdz5s5ub.js",
  "static/chunks/1edklbb2_fnsn.js",
  "static/chunks/3dc---1iim_l7.css",
  "static/chunks/turbopack-3vw9_f-7xp2e-.js"
])
